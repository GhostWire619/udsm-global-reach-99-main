<?php

/**
 * @defgroup plugins_generic_udsmInsights UDSM Insights Dashboard Plugin
 */

/**
 * @file plugins/generic/udsmInsights/index.php
 *
 * Copyright (c) 2024-2026 University of Dar es Salaam
 * Distributed under the GNU GPL v3.
 *
 * @ingroup plugins_generic_udsmInsights
 * @brief Wrapper for UDSM Insights Dashboard plugin.
 */

require_once('UdsmInsightsPlugin.inc.php');

return new UdsmInsightsPlugin();

?>
